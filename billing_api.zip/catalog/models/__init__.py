# catalog/models/__init__.py
from .category import Category  # noqa: F401
from .product import Product    # noqa: F401
